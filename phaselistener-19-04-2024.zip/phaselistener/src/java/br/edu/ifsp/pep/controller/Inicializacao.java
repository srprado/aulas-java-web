
package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.PessoaDAO;
import br.edu.ifsp.pep.model.NivelAcesso;
import br.edu.ifsp.pep.model.Pessoa;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.Startup;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

/**
 *
 * @author aluno
 */
@Startup
@Singleton
public class Inicializacao {
    
    @Inject
    private PessoaDAO pessoaDAO;
    
    @PostConstruct
    public void start() {
        System.out.println("inicializacao.........");
        
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("César");
        pessoa.setLogin("cesar");
        pessoa.setSenha("1");
        pessoa.setNivelAcesso(NivelAcesso.Financeiro);
        
        pessoaDAO.cadastrar(pessoa);
    }

}
