package br.edu.ifsp.pep.model;

/**
 *
 * @author aluno
 */
public enum NivelAcesso {
    Financeiro, Administrativo, Administrador
}
