
package br.edu.ifsp.pep.DAO;

import br.edu.ifsp.pep.model.Estado;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class EstadoDAO {
    
    @PersistenceContext(unitName = "conexaoPU")
    private EntityManager em;
    
    public void inserir(Estado estado){
        em.persist(estado);
    }
    
    public void remover(Estado estado){
        em.remove(em.merge(estado));
    }
    
    public List<Estado> listarEstados(){
        return em.createQuery("SELECT e FROM Estado e",
                Estado.class)
                .getResultList();
    }   
    
     public List<Estado> listarCidades(Estado id){
        return em.createQuery("SELECT c FROM Estado Where id := id ",
                Estado.class)
                .getResultList();
    }   
  
}
