
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.model.Pessoa;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless //EJB - transações
public class PessoaDAO {
    
    @PersistenceContext(unitName = "phaselistenerPU")
    private EntityManager em;
    
    
    public void cadastrar(Pessoa pessoa) {
        em.persist(pessoa);
    }
    
    public Pessoa findUser(String login, String senha){
        return em.createNamedQuery("Pessoa.findUser", Pessoa.class)
                .setParameter("login", login)
    }
            
    public Carro buscarPelaPlaca(String placa) {
        return em.createNamedQuery("Carro.buscarPelaPlaca", Carro.class)
                .setParameter("placa", placa)
                .getSingleResult();
    }        
    
    
}
