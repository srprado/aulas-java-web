
package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.model.Pessoa;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;

@Named
@SessionScoped
public class PessoaController implements Serializable{
    
    private Pessoa pessoaLogada;
    
    public void login(){
        if(pessoaLogada)
        //acessar o banco de dados
    }
    
    public void desconectar(){
        this.pessoaLogada = null;
    }
    
    public Pessoa getPessoaLogada() {
        return pessoaLogada;
    }

    public void setPessoaLogada(Pessoa pessoaLogada) {
        this.pessoaLogada = pessoaLogada;
    }
    
    
    
    
    
}
