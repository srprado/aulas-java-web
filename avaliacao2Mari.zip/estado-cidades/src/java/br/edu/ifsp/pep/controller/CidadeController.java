package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.EstadoDAO;
import br.edu.ifsp.pep.dao.CidadeDAO;
import br.edu.ifsp.pep.model.Cidade;
import br.edu.ifsp.pep.model.Estado;
import br.edu.ifsp.pep.util.Util;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@SessionScoped
public class CidadeController implements Serializable {

    @EJB
    private CidadeDAO cidadeDAO;
    
    private List<Cidade> cidades;
    
    private Cidade cidadeSelecionada;
    private Estado estadoSelecionado;

    private List<Estado> estados;
    
    @EJB
    private EstadoDAO estadoDAO;
    
    public CidadeController() {
    }

    public void mostrarCidade(){
        if(estadoSelecionado!=null&&cidadeSelecionada!=null){
                Util.info("Cidade selecionada: "+cidadeSelecionada.getNome());
            }
    }
    
    public String goToHome() {
        System.out.println("Ir para a página inicial.");
        return "/index";
    }
    
    public List<Cidade> getCidades() {
        if (cidades == null && estadoSelecionado !=null) {
            cidades = cidadeDAO.buscarPorEstado(estadoSelecionado);
        }
        return cidades;
    }
    
    public List<Estado> getEstados() {
        if (estados == null) {
            estados = estadoDAO.buscarTodos();
        }
        return estados;
    }

    public Cidade getCidadeSelecionada() {
        return cidadeSelecionada;
    }

    public void setCidadeSelecionada(Cidade cidadeSelecionada) {
        this.cidadeSelecionada = cidadeSelecionada;
    }
   
    public Estado getEstadoSelecionado() {
        return estadoSelecionado;
    }

    public void setEstadoSelecionado(Estado estadoSelecionado) {
        this.estadoSelecionado = estadoSelecionado;
    }

    public CidadeDAO getCidadeDAO() {
        return cidadeDAO;
    }

    public void setCidadeDAO(CidadeDAO cidadeDAO) {
        this.cidadeDAO = cidadeDAO;
    }

    public EstadoDAO getEstadoDAO() {
        return estadoDAO;
    }

    public void setEstadoDAO(EstadoDAO estadoDAO) {
        this.estadoDAO = estadoDAO;
    }

}
    