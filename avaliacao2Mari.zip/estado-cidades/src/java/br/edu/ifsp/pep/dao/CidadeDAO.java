package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.model.Cidade;
import br.edu.ifsp.pep.model.Estado;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class CidadeDAO {
    
    @PersistenceContext(unitName = "conexaoPU")
    private EntityManager em;
    
    public void inserir(Cidade cidade) {
        em.persist(cidade);
    }
    
    public void remover(Cidade cidade) {
        em.remove(em.merge(cidade));
    }
    
    public List<Cidade> buscarTodos() {
        return em.createQuery("Cidade.buscarTodos", Cidade.class).getResultList();
//        return em.createQuery("SELECT c FROM Cidade c", Cidade.class).getResultList();
    }
    
    public Cidade buscarPorId(Integer id) {
        return em.find(Cidade.class, id);
    }
    
    public List<Cidade> buscarPorEstado(Estado id) {
        return em.createQuery("SELECT c FROM Cidade c WHERE c.estado = :id", Cidade.class).setParameter("id", id).getResultList();
    }
}
