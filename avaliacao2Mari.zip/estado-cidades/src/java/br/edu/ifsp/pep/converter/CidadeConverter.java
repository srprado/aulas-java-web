package br.edu.ifsp.pep.converter;

import br.edu.ifsp.pep.dao.CidadeDAO;
import br.edu.ifsp.pep.model.Cidade;
import jakarta.enterprise.inject.spi.CDI;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;

@FacesConverter("cidadeConverter")
public class CidadeConverter implements Converter<Cidade> {

    @Override
    public Cidade getAsObject(FacesContext context,UIComponent component, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        CidadeDAO cidadeDao = CDI.current().select(CidadeDAO.class).get();
        return cidadeDao.buscarPorId(Integer.valueOf(value));
    }

    @Override
    public String getAsString(FacesContext context,
            UIComponent component, Cidade cidade) {
        if (cidade == null) {
            return null;
        }
        return cidade.getId()   + "";
    }

}
