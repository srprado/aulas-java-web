package br.edu.ifsp.pep.converter;

import br.edu.ifsp.pep.dao.EstadoDAO;
import br.edu.ifsp.pep.model.Estado;
import jakarta.enterprise.inject.spi.CDI;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;

@FacesConverter("estadoConverter")
public class EstadoConverter implements Converter<Estado> {

    @Override
    public Estado getAsObject(FacesContext context,UIComponent component, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        EstadoDAO estadoDao = CDI.current().select(EstadoDAO.class).get();
        return estadoDao.buscarPorId(Integer.valueOf(value));
    }

    @Override
    public String getAsString(FacesContext context,
            UIComponent component, Estado estado) {
        if (estado == null) {
            return null;
        }
        return estado.getId()   + "";
    }

}
