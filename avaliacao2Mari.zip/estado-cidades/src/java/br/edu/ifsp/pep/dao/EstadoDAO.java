package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.model.Estado;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class EstadoDAO {
    
    @PersistenceContext(unitName = "conexaoPU")
    private EntityManager em;
    
    public void inserir(Estado estado) {
        em.persist(estado);
    }
    
    public void remover(Estado estado) {
        em.remove(em.merge(estado));
    }
    
    public List<Estado> buscarTodos() {
        return em.createNamedQuery("Estado.buscarTodos", Estado.class).getResultList();
//        return em.createQuery("SELECT c FROM Estado c", Estado.class).getResultList();
    }
    
    public Estado buscarPorId(Integer id) {
        return em.find(Estado.class, id);
    }
    
}
