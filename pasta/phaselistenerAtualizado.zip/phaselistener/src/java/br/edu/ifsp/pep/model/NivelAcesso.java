
package br.edu.ifsp.pep.model;

public enum NivelAcesso {
        Financeiro, Administrativo, Administrador
    
}
