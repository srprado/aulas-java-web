
package br.edu.ifsp.controller;

import br.edu.ifsp.modelo.Venda;
import br.edu.ifsp.pep.util.Messages;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@SessionScoped
public class vendaController implements Serializable{
    
    private List<Venda> vendas = new ArrayList<>();
    private Venda venda = new Venda();
    private int codigoVenda;
    private Double valorTotal;
    
    
    public void adicionar() {
        if (venda.getCodigo() <= 0) {
            Messages.addMessageWarning("O código da venda deve ser maior que zero.");
        } else if (venda.getValor() <= 0) {
            Messages.addMessageWarning("O valor deve ser maior que zero.");
        } else {
            vendas.add(venda);
            System.out.println("Venda adicionada");
            venda = new Venda();            
        }
    }
    
    public String realizarPagamento(){
        System.out.println("Pagamento");
        if(vendas.isEmpty()){
            Messages.addMessageWarning("Adicione pelo menos um curso.");
            return null;
        }else{
            System.out.println("pagina pagamento");
            return "/pagamento.xhtml";
        }       
    }
    
    public void pagar(){
        int i;
        for (i=0;i<vendas.size();i++) {
            this.valorTotal = this.valorTotal + venda.getValor();            
        }
        vendas.clear();
    }

    public List<Venda> getVendas() {
        return vendas;
    }

    public void setVendas(List<Venda> vendas) {
        this.vendas = vendas;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public int getCodigoVenda() {
        return codigoVenda;
    }

    public void setCodigoVenda(int codigoVenda) {
        this.codigoVenda = codigoVenda;
    }

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }

    
      
}
